// ---- Edit this block before launch ----
const CONFIG = {
  // Static-site form backend, e.g. a Formspree/Getform URL. If empty, registration opens a pre-filled email instead.
  formEndpoint: "",
  contactEmail: "kiprop@eldeerdata.group",
  tiers: [
    { id: "student", label: "Student / Academic", price: 3000 },
    { id: "pro", label: "Professional", price: 15000, selected: true },
    { id: "delegation", label: "Delegation (3 people)", price: 40000 },
  ],
  payment: {
    mpesa: "<b>M-Pesa:</b> Paybill <b>[PAYBILL NO.]</b>, Account <b>SUMMIT + your surname</b>. Enter the confirmation code below.",
    bank: "<b>Bank transfer:</b> [BANK] &middot; <b>[ACCOUNT NAME]</b> &middot; A/C <b>[ACCOUNT NO.]</b> &middot; Branch [BRANCH]. An invoice will be emailed.",
    card: "<b>Card:</b> a secure payment link will be emailed within one working day.",
  },
};
// ----------------------------------------
const $ = (s) => document.querySelector(s);
const kes = (n) => "KES " + Number(n).toLocaleString("en-KE");
const tierEl = $("#tier"), methodEl = $("#method"), form = $("#reg");

if (form) {
  tierEl.innerHTML = CONFIG.tiers.map(t => `<option value="${t.id}"${t.selected ? " selected" : ""}>${t.label} - ${kes(t.price)}</option>`).join("");
  const refresh = () => {
    const t = CONFIG.tiers.find(x => x.id === tierEl.value);
    $("#total").textContent = "Total: " + kes(t.price);
    $("#payinfo").innerHTML = CONFIG.payment[methodEl.value];
    $("#refrow").style.display = methodEl.value === "mpesa" ? "flex" : "none";
  };
  tierEl.onchange = methodEl.onchange = refresh; refresh();

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(form));
    const t = CONFIG.tiers.find(x => x.id === d.tier);
    const rec = { ...d, tier: t.label, amount: t.price, id: "REG-" + Date.now().toString(36).toUpperCase() };
    let sent = false;
    if (CONFIG.formEndpoint) {
      try { sent = (await fetch(CONFIG.formEndpoint, { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(rec) })).ok; } catch (_) {}
    }
    const msg = $("#regmsg"); msg.hidden = false;
    const text = document.createElement("span");
    if (sent) { text.textContent = `Thank you, ${d.name}. Reference ${rec.id}. We will confirm by email once payment is verified.`; msg.replaceChildren(text); form.hidden = true; }
    else {
      const body = encodeURIComponent(Object.entries(rec).map(([k, v]) => `${k}: ${v}`).join("\n"));
      const a = document.createElement("a"); a.href = `mailto:${CONFIG.contactEmail}?subject=Summit registration ${rec.id}&body=${body}`; a.textContent = "email your registration";
      text.textContent = `Reference ${rec.id}. To finish, please `; msg.replaceChildren(text, a, document.createTextNode(" so we can confirm it."));
    }
    msg.scrollIntoView({ behavior: "smooth" });
  });
}
