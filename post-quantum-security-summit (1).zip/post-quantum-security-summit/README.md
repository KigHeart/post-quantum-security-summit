# post-quantum-security-summit
Event landing page for the Post-Quantum Resistant Cryptography & Datacentre Security summit in Nairobi.

## Structure
- `index.html`: landing page, programme, call for talks, registration, sponsors, FAQ
- `styles.css`, `script.js`: styling; registration form logic

## Before launch
Edit the `CONFIG` block at the top of `script.js`: set `formEndpoint` (e.g. Formspree) so registrations are collected, fill in M-Pesa/bank details, and confirm ticket prices. Card and M-Pesa checkout need a payment provider (Pesapal, Flutterwave, Daraja); this static site only shows payment instructions.
